## Install Required  packages
pip install -r requirements.txt

## Streamlit run a file
streamlit run Approval.py

## Docker images
docker build -t streamlit .

## Docker Container
docker run -p 8501:8501 streamlit
