import streamlit as st
import pandas as pd
import io
#import xlsxwriter
import time

buffer = io.BytesIO()


user  = st.selectbox('Pick one',['Image','Data','show_Combinations','DataFrame'])

def input_data():
    
    try:
        
        new = st.file_uploader('Upload a Excel')
        data = pd.read_excel(new)
        time.sleep(2)
        return data
        
    except:
        
        with open('Inputdata.xlsx', 'rb') as f:
            st.download_button('Sample Worksheet', f, file_name='Inputdata.xlsx')
            
            
def show_combinations():
    
    event =['accepted','rejected','skip']
    combinations = []
    df = input_data()
    try:
        
        list1 = list(df['status'])

        for i in range(0,len(list1)+1):

            for j in event:
                if j == 'accepted':
                    combinations.append(f'{list1[i]}-->{j}-->{list1[i+1]}')
                elif j == 'rejected':
                    combinations.append(f'{list1[i]}-->{j}-->{"Rejected OR On_Hold"}')
                elif j == 'skip':
                    combinations.append(f'{list1[i]}-->{j}-->{list1[i+1]}')
    except:
        pass
    
    finally:
        return combinations
    

def new_status():
    
    comb = list(show_combinations())
    new_df = pd.DataFrame(columns = ['status','event','new_status'] )

    new_df['status'] = [i.split('-->')[0] for i in comb]
    new_df['event'] =  [i.split('-->')[1] for i in comb]
    new_df['new_status'] = [i.split('-->')[2] for i in comb]
    
    with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
        new_df.to_excel(writer)
        
        writer.close()
    
    st.download_button(
        label="Download Excel worksheets",
        data=buffer,
        file_name="Combinations.xlsx",
        mime="application/vnd.ms-excel"
    )
    
    
    return new_df
    

    

if user == 'Data':
    st.dataframe(input_data())
    
elif user == "show_Combinations":
    st.write(show_combinations())
    
elif user == "DataFrame":
    st.write(new_status())
elif user == 'Image':
    st.title("FLOW CHAT")
    st.image('Processing.JPG')